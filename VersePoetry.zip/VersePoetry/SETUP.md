# VersePoetry: running it on your own PC

## 1. Folder layout

Your folder must look like this (Flask is strict about the folder names):

```
VersePoetry/
├── app.py                 <- replace with the new one
├── requirements.txt       <- new
├── schema.sql             <- new
├── .env                   <- you create this from .env.example
├── templates/             <- ALL the .html files go here
│   ├── index.html, about.html, contact.html, login.html,
│   ├── profile.html, admin_login.html, admin_dashboard.html,
│   ├── edit_poem.html
│   ├── login.html             <- replace with the new one (email field)
│   ├── verify_email.html      <- new (enter the emailed code)
│   └── poem_submission.html   <- replace with the new one
└── statics/               <- note: "statics", not "static"
    └── images/
        ├── logo.jpg
        └── about.jpeg
```

`uploads/` is created automatically.

## 2. Install the tools

- Python 3.9 or newer (tick "Add Python to PATH" in the installer)
- MySQL Server (and optionally MySQL Workbench). Remember the root password you set.

## 3. Install the Python packages

Open a terminal in the project folder:

```
python -m venv venv
venv\Scripts\activate          (macOS/Linux: source venv/bin/activate)
pip install -r requirements.txt 
```

## 4. Create the database

```
mysql -u root -p < schema.sql
```

(or open `schema.sql` in MySQL Workbench and run the whole script).

## 5. Create your .env

Copy `.env.example` to `.env` and fill in your own MySQL password,
a secret key, an admin setup key, and the Gmail settings below.

### Gmail settings (needed for email verification)

1. Turn on 2-Step Verification for your Google account.
2. Go to https://myaccount.google.com/apppasswords and create an app password.
3. In `.env` set `MAIL_USERNAME` to your Gmail address and `MAIL_PASSWORD`
   to the 16-character app password (spaces are fine, they are ignored).
4. Restart the server after editing `.env`.

When someone registers, a 6-digit code is emailed to them. The account is
created only after they enter it. Accounts created before this change keep
working (they log in with contact number + password as before).

## 6. Run

```
python app.py
```

Open http://127.0.0.1:5000

- Users: register on the Login page (10-digit number + password).
- Admin: go to http://127.0.0.1:5000/admin. The first visit shows
  "Create First Admin Account"; use the ADMIN_SETUP_KEY from your .env.

## Common errors

| Message | Fix |
|---|---|
| `Access denied for user 'root'` | Wrong MYSQL_PASSWORD in .env |
| `Unknown database 'versepoetry_db'` | Step 4 not done |
| `Can't connect to MySQL server` | MySQL service isn't running |
| `TemplateNotFound` | HTML files aren't inside `templates/` |
| Images missing | Copy `logo.jpg` and `about.jpeg` into `statics/images/` |
| `No module named ...` | venv not activated, or step 3 skipped |
| "Email sending is not set up" | `MAIL_USERNAME` / `MAIL_PASSWORD` missing in `.env`, or server not restarted |
| "verification email could not be sent" (terminal shows `535 Username and Password not accepted`) | Wrong app password, or 2-Step Verification is off. Create a new app password |
| Code email not in inbox | Check spam; use "Resend code" (30-second gap) |
