-- VersePoetry: clean schema for a fresh install.
-- Run once:   mysql -u root -p < schema.sql
-- (or open in MySQL Workbench and run the whole script)

CREATE DATABASE IF NOT EXISTS versepoetry_db;
USE versepoetry_db;

CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    registration_date DATETIME,
    contact_number VARCHAR(15) UNIQUE,
    password_hash VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS poems (
    poem_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    file_path VARCHAR(255),
    status VARCHAR(20) DEFAULT 'Pending',
    created_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS admins (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    admin_name VARCHAR(100),
    username VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS contact_messages (
    message_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME
);

CREATE TABLE IF NOT EXISTS qr_login_requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    token_hash VARCHAR(255) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    user_id INT,
    created_at DATETIME,
    expires_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS remembered_devices (
    device_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token_hash VARCHAR(255) UNIQUE NOT NULL,
    created_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS poem_status_history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    poem_id INT,
    old_status VARCHAR(20),
    new_status VARCHAR(20),
    changed_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_poem_status ON poems(status);

CREATE OR REPLACE VIEW approved_poems AS
SELECT poem_id, user_id, title, content, created_at
FROM poems
WHERE status = 'Approved';


DROP TRIGGER IF EXISTS poem_status_update;

DELIMITER //
CREATE TRIGGER poem_status_update
AFTER UPDATE ON poems
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO poem_status_history (poem_id, old_status, new_status)
        VALUES (OLD.poem_id, OLD.status, NEW.status);
    END IF;
END //
DELIMITER ;
