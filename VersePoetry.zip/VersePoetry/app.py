import os
import re
import hmac
import time
import hashlib
import random
import secrets
import mysql.connector

from datetime import datetime, timedelta
from functools import wraps

# Load settings from a local .env file (see .env.example).
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass

from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, session, send_from_directory, abort
)

from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename


# ==================================================
# FLASK CONFIGURATION
# ==================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    static_folder="statics",
    static_url_path="/static"
)

# Set FLASK_SECRET_KEY in .env so logins survive server restarts.
app.secret_key = os.environ.get(
    "FLASK_SECRET_KEY",
    secrets.token_hex(32)
)

app.config.update(
    MAIL_SERVER="smtp.gmail.com",
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USE_SSL=False,
    MAIL_USERNAME=os.environ.get("MAIL_USERNAME", "").strip(),
    # Google shows app passwords in 4 groups of 4 letters separated by
    # spaces; the spaces are not part of the password, so remove them.
    MAIL_PASSWORD=os.environ.get("MAIL_PASSWORD", "").replace(" ", ""),
    MAIL_DEFAULT_SENDER=os.environ.get("MAIL_USERNAME", "").strip()
)

mail = Mail(app)

# MySQL configuration. Values come from your .env file.
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "port": int(os.environ.get("MYSQL_PORT", "3306")),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", ""),
    "database": os.environ.get("MYSQL_DATABASE", "versepoetry_db"),
    "autocommit": False,
}

UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_POEM_EXTENSIONS = {"txt", "pdf", "docx"}
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB per request

OTP_EXPIRY_MINUTES = 5
OTP_MAX_ATTEMPTS = 5
VERIFY_RESEND_SECONDS = 30  # minimum gap between verification emails

EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# Admin registration key. Set ADMIN_SETUP_KEY in .env to enable
# creating the first admin account.
ADMIN_SETUP_KEY = os.environ.get("ADMIN_SETUP_KEY", "")


# ==================================================
# DATABASE
# ==================================================

class MySQLDatabase:
    """Small compatibility wrapper so existing db.execute(...) calls keep working."""

    def __init__(self):
        self.connection = mysql.connector.connect(**MYSQL_CONFIG)
        # buffered=True avoids "Unread result found" errors when a query
        # is followed by another query on the same cursor.
        self.cursor = self.connection.cursor(dictionary=True, buffered=True)

    def execute(self, query, params=None):
        # Convert SQLite parameter markers to MySQL Connector markers.
        query = query.replace("?", "%s")
        # Keep the existing code's generated-ID query working with MySQL.
        if "last_insert_rowid()" in query.lower():
            query = "SELECT LAST_INSERT_ID() AS last_insert_rowid"
        self.cursor.execute(query, params or ())
        return self.cursor

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        try:
            if exc_type is None:
                self.connection.commit()
            else:
                self.connection.rollback()
        finally:
            self.cursor.close()
            self.connection.close()
        return False


def get_db():
    return MySQLDatabase()


# ==================================================
# HELPER FUNCTIONS
# ==================================================

def admin_required(view):

    @wraps(view)
    def wrapped(*args, **kwargs):

        if "admin_id" not in session:
            flash("Please log in as Admin first.", "error")
            return redirect(url_for("admin_dashboard"))

        return view(*args, **kwargs)

    return wrapped


def login_required(view):

    @wraps(view)
    def wrapped(*args, **kwargs):

        if "user_id" not in session:
            flash("Please log in first.", "error")
            return redirect(url_for("login"))

        return view(*args, **kwargs)

    return wrapped


def send_otp_email(email, otp):

    message = Message(
        subject="VersePoetry Login OTP",
        recipients=[email],
        body=(
            f"Your VersePoetry OTP is {otp}.\n\n"
            f"This OTP expires in {OTP_EXPIRY_MINUTES} minutes."
        )
    )

    mail.send(message)


def clear_otp_session():

    for key in (
        "pending_otp",
        "pending_email",
        "pending_name",
        "otp_created_at",
        "otp_attempts"
    ):
        session.pop(key, None)


# ---------- Registration email verification helpers ----------

def mail_is_configured():
    return bool(
        app.config["MAIL_USERNAME"] and app.config["MAIL_PASSWORD"]
    )


def hash_otp(email, otp):
    """Keyed hash of the OTP.

    Flask sessions are signed but NOT encrypted: anything stored in the
    session cookie can be read by the user. Storing the plain OTP there
    would let people read the code from their own cookie and skip email
    verification, so only a keyed hash (HMAC) is stored.
    """
    return hmac.new(
        app.secret_key.encode("utf-8"),
        f"{email}:{otp}".encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def clear_registration_session():

    for key in (
        "reg_name",
        "reg_email",
        "reg_contact",
        "reg_password_hash",
        "reg_otp_hash",
        "reg_otp_created_at",
        "reg_otp_attempts",
        "reg_last_sent"
    ):
        session.pop(key, None)


def send_verification_email(email, otp):

    message = Message(
        subject="Verify your VersePoetry email",
        recipients=[email],
        body=(
            "Welcome to VersePoetry!\n\n"
            f"Your email verification code is {otp}.\n\n"
            f"This code expires in {OTP_EXPIRY_MINUTES} minutes.\n"
            "If you did not try to register, you can ignore this email."
        )
    )

    mail.send(message)


def issue_verification_code(email):
    """Create a fresh OTP, remember its hash in the session and email it.

    Returns True when the email was sent, False otherwise.
    """
    otp = f"{random.SystemRandom().randint(0, 999999):06d}"

    try:
        send_verification_email(email, otp)

    except Exception:

        app.logger.exception("Failed to send verification email")

        return False

    session["reg_otp_hash"] = hash_otp(email, otp)
    session["reg_otp_created_at"] = time.time()
    session["reg_otp_attempts"] = 0
    session["reg_last_sent"] = time.time()

    return True


def get_current_user():

    user_id = session.get("user_id")

    if not user_id:
        return None

    with get_db() as db:

        return db.execute(
            """
            SELECT user_id, name, email, registration_date
            FROM users
            WHERE user_id = ?
            """,
            (user_id,)
        ).fetchone()



# ==================================================
# HOME PAGE
# ==================================================

@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html")


# ==================================================
# ABOUT PAGE
# ==================================================

@app.route("/about")
def about():
    return render_template("about.html")


# ==================================================
# CONTACT PAGE
# ==================================================

@app.route("/contact", methods=["GET", "POST"])
def contact():

    if request.method == "POST":

        name = request.form.get(
            "name", ""
        ).strip()

        email = request.form.get(
            "email", ""
        ).strip().lower()

        message = request.form.get(
            "message", ""
        ).strip()

        if not name or not email or not message:

            flash(
                "Please fill in all fields.",
                "error"
            )

            return redirect(url_for("contact"))

        with get_db() as db:

            db.execute(
                """
                INSERT INTO contact_messages
                (name, email, message, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    name,
                    email,
                    message,
                    datetime.now().strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                )
            )

        flash(
            "Your message has been saved successfully.",
            "success"
        )

        return redirect(url_for("contact"))

    return render_template("contact.html")


# ==================================================
# ADMIN DASHBOARD / LOGIN PAGE
# ==================================================

@app.route("/admin", methods=["GET"])
def admin_dashboard():

    if "admin_id" in session:
        return redirect(url_for("admin_panel"))

    with get_db() as db:

        admin_exists = db.execute(
            "SELECT admin_id FROM admins LIMIT 1"
        ).fetchone()

    registration_open = (
        admin_exists is None and bool(ADMIN_SETUP_KEY)
    )

    setup_key_configured = (
        admin_exists is not None or bool(ADMIN_SETUP_KEY)
    )

    return render_template(
        "admin_login.html",
        registration_open=registration_open,
        setup_key_configured=setup_key_configured,
        logged_in=False
    )


# ==================================================
# ADMIN REGISTRATION
# ==================================================

@app.route("/admin/register", methods=["POST"])
def admin_register():

    admin_name = request.form.get(
        "admin_name", ""
    ).strip()

    username = request.form.get(
        "username", ""
    ).strip()

    password = request.form.get(
        "password", ""
    )

    confirm_password = request.form.get(
        "confirm_password", ""
    )

    setup_key = request.form.get(
        "setup_key", ""
    )

    if not ADMIN_SETUP_KEY:

        flash(
            "Admin registration is disabled.",
            "error"
        )

        return redirect(url_for("admin_dashboard"))

    if not secrets.compare_digest(
        setup_key.encode("utf-8"), ADMIN_SETUP_KEY.encode("utf-8")
    ):

        flash(
            "Invalid admin setup key.",
            "error"
        )

        return redirect(url_for("admin_dashboard"))

    if not admin_name or not username or not password:

        flash(
            "Please fill in all fields.",
            "error"
        )

        return redirect(url_for("admin_dashboard"))

    if len(password) < 8:

        flash(
            "Password must contain at least 8 characters.",
            "error"
        )

        return redirect(url_for("admin_dashboard"))

    if password != confirm_password:

        flash(
            "Passwords do not match.",
            "error"
        )

        return redirect(url_for("admin_dashboard"))

    with get_db() as db:

        existing_admin = db.execute(
            "SELECT admin_id FROM admins LIMIT 1"
        ).fetchone()

        if existing_admin:

            flash(
                "Admin registration is already closed.",
                "error"
            )

            return redirect(url_for("admin_dashboard"))

        db.execute(
            """
            INSERT INTO admins
            (admin_name, username, password_hash, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (
                admin_name,
                username,
                generate_password_hash(password),
                datetime.now().strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
            )
        )

    flash(
        "Admin account created successfully. Please log in.",
        "success"
    )

    return redirect(url_for("admin_dashboard"))


# ==================================================
# ADMIN LOGIN
# ==================================================

@app.route("/admin/login", methods=["POST"])
def admin_login():

    username = request.form.get(
        "username", ""
    ).strip()

    password = request.form.get(
        "password", ""
    )

    with get_db() as db:

        admin = db.execute(
            """
            SELECT admin_id, admin_name, password_hash
            FROM admins
            WHERE username = ?
            """,
            (username,)
        ).fetchone()

    if not admin or not check_password_hash(
        admin["password_hash"], password
    ):

        flash(
            "Invalid admin username or password.",
            "error"
        )

        return redirect(url_for("admin_dashboard"))

    session.clear()

    session["admin_id"] = admin["admin_id"]
    session["admin_name"] = admin["admin_name"]

    return redirect(url_for("admin_panel"))


# ==================================================
# ADMIN PANEL
# ==================================================

@app.route("/admin/panel")
@admin_required
def admin_panel():

    with get_db() as db:

        pending_poems = db.execute("""
            SELECT
                poems.poem_id AS id,
                poems.title,
                poems.content,
                poems.file_path,
                poems.created_at,
                users.name AS author_name
            FROM poems
            JOIN users
                ON poems.user_id = users.user_id
            WHERE poems.status = 'Pending'
            ORDER BY poems.poem_id DESC
        """).fetchall()

        approved_poems = db.execute("""
            SELECT
                poems.poem_id AS id,
                poems.title,
                poems.content,
                poems.file_path,
                poems.created_at,
                users.name AS author_name
            FROM poems
            JOIN users ON poems.user_id = users.user_id
            WHERE poems.status = 'Approved'
            ORDER BY poems.poem_id DESC
        """).fetchall()

        rejected_poems = db.execute("""
            SELECT
                poems.poem_id AS id,
                poems.title,
                poems.content,
                poems.file_path,
                poems.created_at,
                users.name AS author_name
            FROM poems
            JOIN users ON poems.user_id = users.user_id
            WHERE poems.status = 'Rejected'
            ORDER BY poems.poem_id DESC
        """).fetchall()

    return render_template(
        "admin_dashboard.html",
        logged_in=True,
        admin_name=session.get("admin_name", "Admin"),
        pending_poems=pending_poems,
        approved_poems=approved_poems,
        rejected_poems=rejected_poems,
        pending_count=len(pending_poems),
        approved_count=len(approved_poems),
        rejected_count=len(rejected_poems)
    )


# ==================================================
# VIEW UPLOADED POEM FILE (ADMIN ONLY)
# ==================================================

@app.route("/admin/poem-file/<int:poem_id>")
@admin_required
def view_poem_file(poem_id):
    with get_db() as db:
        poem = db.execute(
            "SELECT file_path FROM poems WHERE poem_id = ?",
            (poem_id,)
        ).fetchone()

    if poem is None or not poem["file_path"]:
        flash("No uploaded file was found for this poem.", "error")
        return redirect(url_for("admin_panel"))

    # Only serve a filename stored in the database, never a user-supplied path.
    filename = os.path.basename(poem["file_path"])
    if not filename or secure_filename(filename) != filename:
        abort(404)

    full_path = os.path.join(UPLOAD_FOLDER, filename)
    if not os.path.isfile(full_path):
        flash("The uploaded file is missing from the uploads folder.", "error")
        return redirect(url_for("admin_panel"))

    extension = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    # Browsers can display PDF/TXT inline. DOCX is downloaded to open in Word.
    return send_from_directory(
        UPLOAD_FOLDER,
        filename,
        as_attachment=(extension == "docx"),
        download_name=filename
    )


# ==================================================
# ADMIN POEM APPROVAL / REJECTION
# ==================================================

@app.route(
    "/admin/review/<int:poem_id>",
    methods=["POST"]
)
@admin_required
def review_poem(poem_id):

    action = request.form.get(
        "action", ""
    ).strip().lower()

    if action not in ("approve", "reject"):

        flash(
            "Invalid action.",
            "error"
        )

        return redirect(url_for("admin_panel"))

    new_status = (
        "Approved"
        if action == "approve"
        else "Rejected"
    )

    with get_db() as db:

        poem = db.execute(
            "SELECT poem_id FROM poems WHERE poem_id = ?",
            (poem_id,)
        ).fetchone()

        if poem is None:

            flash(
                "Poem not found.",
                "error"
            )

            return redirect(url_for("admin_panel"))

        db.execute(
            """
            UPDATE poems
            SET status = ?
            WHERE poem_id = ?
            """,
            (new_status, poem_id)
        )

    flash(
        f"Poem {new_status.lower()} successfully.",
        "success"
    )

    return redirect(url_for("admin_panel"))


# ==================================================
# ADMIN EDIT POEM
# ==================================================

@app.route("/admin/edit-poem/<int:poem_id>", methods=["GET", "POST"])
@admin_required
def edit_poem(poem_id):
    with get_db() as db:
        poem = db.execute(
            "SELECT poem_id AS id, title, content, status FROM poems WHERE poem_id = ?",
            (poem_id,)
        ).fetchone()

        if poem is None:
            flash("Poem not found.", "error")
            return redirect(url_for("admin_panel"))

        if request.method == "POST":
            title = request.form.get("title", "").strip()
            content = request.form.get("content", "").strip()
            if not title or not content:
                flash("Title and poem content are required.", "error")
                return render_template("edit_poem.html", poem=poem)

            db.execute(
                "UPDATE poems SET title = ?, content = ? WHERE poem_id = ?",
                (title, content, poem_id)
            )

        else:
            return render_template("edit_poem.html", poem=poem)

    flash("Poem updated successfully.", "success")
    return redirect(url_for("admin_panel"))


# ==================================================
# ADMIN LOGOUT
# ==================================================

@app.route("/admin/logout", methods=["POST"])
@admin_required
def admin_logout():

    session.clear()

    flash(
        "Admin logged out successfully.",
        "success"
    )

    return redirect(url_for("admin_dashboard"))


# ==================================================
# USER AUTHENTICATION HELPERS
# ==================================================

def user_auth_redirect(user_id, message=None):
    """Start a normal logged-in session without any QR-session logic."""
    session.clear()
    session["user_id"] = user_id
    if message:
        flash(message, "success")
    return redirect(url_for("poem_submission"))


@app.route("/register", methods=["POST"])
def register():
    """Step 1: validate the form, email a code, hold the details in the session.

    The account is NOT created here. It is created in verify_email() only
    after the person proves they own the email address.
    """
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    contact_number = request.form.get("contact_number", "").strip()
    password = request.form.get("password", "")
    confirm_password = request.form.get("confirm_password", "")

    if not name or not email or not contact_number or not password:
        flash("Please fill in all registration fields.", "error")
        return redirect(url_for("login") + "#register")
    if len(email) > 150 or not EMAIL_PATTERN.match(email):
        flash("Enter a valid email address.", "error")
        return redirect(url_for("login") + "#register")
    if not contact_number.isdigit() or len(contact_number) != 10:
        flash("Enter a valid 10-digit contact number.", "error")
        return redirect(url_for("login") + "#register")
    if len(password) < 8:
        flash("Password must contain at least 8 characters.", "error")
        return redirect(url_for("login") + "#register")
    if password != confirm_password:
        flash("Passwords do not match.", "error")
        return redirect(url_for("login") + "#register")

    if not mail_is_configured():
        flash(
            "Email sending is not set up. Add MAIL_USERNAME and "
            "MAIL_PASSWORD to the .env file and restart the server.",
            "error"
        )
        return redirect(url_for("login") + "#register")

    with get_db() as db:
        phone_taken = db.execute(
            "SELECT user_id FROM users WHERE contact_number = ?",
            (contact_number,)
        ).fetchone()
        email_taken = db.execute(
            "SELECT user_id FROM users WHERE email = ?",
            (email,)
        ).fetchone()

    if phone_taken:
        flash("This contact number is already registered. Please log in.", "error")
        return redirect(url_for("login"))
    if email_taken:
        flash("This email is already registered. Please log in.", "error")
        return redirect(url_for("login"))

    clear_registration_session()

    session["reg_name"] = name
    session["reg_email"] = email
    session["reg_contact"] = contact_number
    session["reg_password_hash"] = generate_password_hash(password)

    if not issue_verification_code(email):
        clear_registration_session()
        flash(
            "The verification email could not be sent. Check the email "
            "address and the Gmail settings in your .env file.",
            "error"
        )
        return redirect(url_for("login") + "#register")

    flash(
        f"We sent a 6-digit code to {email}. Check your inbox and spam folder.",
        "success"
    )
    return redirect(url_for("verify_email"))


@app.route("/verify-email", methods=["GET", "POST"])
def verify_email():
    """Step 2: check the code and, if correct, create the account."""

    if not session.get("reg_email") or not session.get("reg_otp_hash"):
        flash("Please register first.", "error")
        return redirect(url_for("login"))

    email = session["reg_email"]

    if request.method == "GET":
        return render_template("verify_email.html", email=email)

    entered_otp = request.form.get("otp", "").strip()

    if time.time() - session.get("reg_otp_created_at", 0) > OTP_EXPIRY_MINUTES * 60:
        clear_registration_session()
        flash("The code expired. Please register again.", "error")
        return redirect(url_for("login"))

    if session.get("reg_otp_attempts", 0) >= OTP_MAX_ATTEMPTS:
        clear_registration_session()
        flash("Too many wrong attempts. Please register again.", "error")
        return redirect(url_for("login"))

    if not hmac.compare_digest(
        hash_otp(email, entered_otp),
        session["reg_otp_hash"]
    ):
        session["reg_otp_attempts"] = session.get("reg_otp_attempts", 0) + 1
        flash("Incorrect code. Please try again.", "error")
        return render_template("verify_email.html", email=email)

    # Code is correct: create the account.
    name = session["reg_name"]
    contact_number = session["reg_contact"]
    password_hash = session["reg_password_hash"]

    try:
        with get_db() as db:
            # Re-check: someone may have registered these details meanwhile.
            taken = db.execute(
                "SELECT user_id FROM users WHERE contact_number = ? OR email = ?",
                (contact_number, email)
            ).fetchone()
            if taken is None:
                db.execute(
                    "INSERT INTO users (name, email, registration_date, contact_number, password_hash) VALUES (?, ?, ?, ?, ?)",
                    (name, email, datetime.now().strftime("%Y-%m-%d"),
                     contact_number, password_hash)
                )
                user_id = db.execute("SELECT last_insert_rowid()").fetchone()["last_insert_rowid"]
    except mysql.connector.IntegrityError:
        taken = True

    if taken:
        clear_registration_session()
        flash("This email or contact number is already registered. Please log in.", "error")
        return redirect(url_for("login"))

    return user_auth_redirect(
        user_id,
        "Email verified. Welcome to VersePoetry!"
    )


@app.route("/resend-verification", methods=["POST"])
def resend_verification():

    if not session.get("reg_email") or not session.get("reg_otp_hash"):
        flash("Please register first.", "error")
        return redirect(url_for("login"))

    wait = VERIFY_RESEND_SECONDS - (time.time() - session.get("reg_last_sent", 0))

    if wait > 0:
        flash(f"Please wait {int(wait) + 1} seconds before requesting another code.", "error")
        return redirect(url_for("verify_email"))

    if issue_verification_code(session["reg_email"]):
        flash("A new code has been sent.", "success")
    else:
        flash("The email could not be sent. Check the Gmail settings in your .env file.", "error")

    return redirect(url_for("verify_email"))


@app.route("/phone-login", methods=["POST"])
def phone_login():
    contact_number = request.form.get("contact_number", "").strip()
    password = request.form.get("password", "")

    if not contact_number or not password:
        flash("Enter your contact number and password.", "error")
        return redirect(url_for("login"))

    with get_db() as db:
        user = db.execute(
            "SELECT user_id, password_hash FROM users WHERE contact_number = ?",
            (contact_number,)
        ).fetchone()

    if not user or not user["password_hash"] or not check_password_hash(user["password_hash"], password):
        flash("Incorrect contact number or password.", "error")
        return redirect(url_for("login"))

    return user_auth_redirect(user["user_id"], "Login successful.")


# ==================================================
# USER LOGIN - EMAIL OTP (NO QR LOGIN)
# ==================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "GET":
        return render_template("login.html")

    email = request.form.get(
        "email", ""
    ).strip().lower()

    if not email:

        flash(
            "Please enter your email address.",
            "error"
        )

        return redirect(url_for("login"))

    if (
        not app.config["MAIL_USERNAME"]
        or not app.config["MAIL_PASSWORD"]
    ):

        flash(
            "Email configuration is missing. "
            "Set MAIL_USERNAME and MAIL_PASSWORD.",
            "error"
        )

        return redirect(url_for("login"))

    otp = f"{random.SystemRandom().randint(0, 999999):06d}"

    session["pending_email"] = email
    session["pending_otp"] = otp
    session["otp_created_at"] = datetime.utcnow().isoformat()
    session["otp_attempts"] = 0

    try:
        send_otp_email(email, otp)

    except Exception:

        app.logger.exception(
            "Failed to send login OTP"
        )

        clear_otp_session()

        flash(
            "OTP email could not be sent. Check Gmail settings.",
            "error"
        )

        return redirect(url_for("login"))

    flash(
        "OTP sent. Check your inbox and spam folder.",
        "success"
    )

    return redirect(url_for("otp_verification"))


# ==================================================
# OTP VERIFICATION
# ==================================================

@app.route(
    "/otp-verification",
    methods=["GET", "POST"]
)
def otp_verification():

    if (
        not session.get("pending_email")
        or not session.get("pending_otp")
    ):

        flash(
            "Please request an OTP first.",
            "error"
        )

        return redirect(url_for("login"))

    if request.method == "GET":

        return render_template(
            "otp_verification.html",
            email=session["pending_email"]
        )

    entered_otp = request.form.get(
        "otp", ""
    ).strip()

    try:

        created = datetime.fromisoformat(
            session.get("otp_created_at", "")
        )

    except (ValueError, TypeError):

        created = datetime.min

    if datetime.utcnow() - created > timedelta(
        minutes=OTP_EXPIRY_MINUTES
    ):

        clear_otp_session()

        flash(
            "OTP expired. Please request a new OTP.",
            "error"
        )

        return redirect(url_for("login"))

    if session.get("otp_attempts", 0) >= OTP_MAX_ATTEMPTS:

        clear_otp_session()

        flash(
            "Too many attempts. Request a new OTP.",
            "error"
        )

        return redirect(url_for("login"))

    if not secrets.compare_digest(
        entered_otp.encode("utf-8"),
        session["pending_otp"].encode("utf-8")
    ):

        session["otp_attempts"] += 1

        flash(
            "Incorrect OTP. Please try again.",
            "error"
        )

        return render_template(
            "otp_verification.html",
            email=session["pending_email"]
        )

    email = session["pending_email"]

    with get_db() as db:

        user = db.execute(
            "SELECT user_id FROM users WHERE email = ?",
            (email,)
        ).fetchone()

        if user:

            user_id = user["user_id"]

        else:

            db.execute(
                """
                INSERT INTO users
                (name, email, registration_date)
                VALUES (?, ?, ?)
                """,
                (
                    "",
                    email,
                    datetime.now().strftime("%Y-%m-%d")
                )
            )

            user_id = db.execute(
                "SELECT last_insert_rowid()"
            ).fetchone()["last_insert_rowid"]

    return user_auth_redirect(user_id, "Email verified successfully.")


# ==================================================
# USER PROFILE
# ==================================================

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():

    user = get_current_user()

    if user is None:

        session.clear()

        return redirect(url_for("login"))

    if request.method == "POST":

        name = request.form.get(
            "name", ""
        ).strip()

        if not name:

            flash(
                "Please enter your name.",
                "error"
            )

        else:

            with get_db() as db:

                db.execute(
                    """
                    UPDATE users
                    SET name = ?
                    WHERE user_id = ?
                    """,
                    (name, user["user_id"])
                )

            flash(
                "Profile updated successfully.",
                "success"
            )

            return redirect(url_for("profile"))

    user = get_current_user()

    with get_db() as db:

        counts = db.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending,
                SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) AS approved,
                SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) AS rejected
            FROM poems
            WHERE user_id = ?
            """,
            (user["user_id"],)
        ).fetchone()

        poems = db.execute(
            """
            SELECT poem_id, title, status, created_at, file_path
            FROM poems
            WHERE user_id = ?
            ORDER BY poem_id DESC
            """,
            (user["user_id"],)
        ).fetchall()

    poem_counts = {
        key: int(counts[key] or 0)
        for key in ("total", "pending", "approved", "rejected")
    }

    return render_template(
        "profile.html",
        user=user,
        poems=poems,
        poem_counts=poem_counts
    )


# ==================================================
# POEM SUBMISSION
# ==================================================

@app.route("/poem-submission", methods=["GET", "POST"])
@login_required
def poem_submission():

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        poem_file = request.files.get("poem_file")

        if not title:
            flash("Please enter the poem title.", "error")
            return redirect(url_for("poem_submission"))

        file_path = None

        if poem_file and poem_file.filename:
            original_name = secure_filename(poem_file.filename)

            if not original_name or "." not in original_name:
                flash("Please choose a valid TXT, PDF or DOCX file.", "error")
                return redirect(url_for("poem_submission"))

            extension = original_name.rsplit(".", 1)[1].lower()
            if extension not in ALLOWED_POEM_EXTENSIONS:
                flash("Upload only TXT, PDF or DOCX files.", "error")
                return redirect(url_for("poem_submission"))

            unique_filename = f"{secrets.token_hex(8)}_{original_name}"
            poem_file.save(os.path.join(UPLOAD_FOLDER, unique_filename))
            file_path = unique_filename

        if not content and not file_path:
            flash("Please enter your poem or upload a poem file.", "error")
            return redirect(url_for("poem_submission"))

        with get_db() as db:
            db.execute(
                """
                INSERT INTO poems
                    (user_id, title, content, status, created_at, file_path)
                VALUES (?, ?, ?, 'Pending', ?, ?)
                """,
                (
                    session["user_id"],
                    title,
                    content,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    file_path
                )
            )

        flash("Your poem was submitted successfully.", "success")
        return redirect(url_for("poem_submission"))

    with get_db() as db:
        poems = db.execute(
            """
            SELECT poem_id, title, status, created_at
            FROM poems
            WHERE user_id = ?
            ORDER BY poem_id DESC
            """,
            (session["user_id"],)
        ).fetchall()

    return render_template("poem_submission.html", poems=poems)


# ==================================================
# USER LOGOUT
# ==================================================

@app.route("/logout")
def logout():

    session.clear()

    flash(
        "You have been logged out.",
        "success"
    )

    return redirect(url_for("login"))


# ==================================================
# START FLASK SERVER
# ==================================================

@app.errorhandler(413)
def file_too_large(_error):
    return "Uploaded file is too large. Maximum size is 10 MB.", 413


if __name__ == "__main__":

    # Fail early with a readable message if MySQL is not reachable.
    try:
        _conn = mysql.connector.connect(**MYSQL_CONFIG)
        _conn.close()
    except mysql.connector.Error as exc:
        raise SystemExit(
            "\nCould not connect to MySQL: "
            f"{exc}\n"
            "Check that MySQL is running, that schema.sql has been imported, "
            "and that MYSQL_USER / MYSQL_PASSWORD in your .env are correct.\n"
        )

    # 127.0.0.1 = reachable only from this PC. debug=True exposes an
    # interactive debugger, so it must never be reachable from the network.
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=os.environ.get("FLASK_DEBUG", "1") == "1"
    )
